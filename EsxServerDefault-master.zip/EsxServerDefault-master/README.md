# EsxServerDefault

Server completamente default para os que tem dificuldade em se iniciar.

Ja vem com server cfg e start bat.

Server Completamente actualizado.
